import { readdir } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import sharp from 'sharp'

const pub = path.join(process.cwd(), 'public')
const galleryDir = path.join(pub, 'gallery')

// 1) Gallery images -> square WebP thumbnail + full WebP for lightbox
const files = (await readdir(galleryDir)).filter((f) => /\.jpe?g$/i.test(f))
for (const file of files) {
  const base = file.replace(/\.jpe?g$/i, '')
  const input = path.join(galleryDir, file)

  // Square thumbnail for the grid (retina-friendly at 500px)
  await sharp(input)
    .resize(500, 500, { fit: 'cover', position: 'attention' })
    .webp({ quality: 68 })
    .toFile(path.join(galleryDir, `${base}.thumb.webp`))

  // Full image for lightbox (max 1400px, uncropped)
  await sharp(input)
    .resize(1400, 1400, { fit: 'inside', withoutEnlargement: true })
    .webp({ quality: 74 })
    .toFile(path.join(galleryDir, `${base}.webp`))

  console.log('optimized', base)
}

// 2) Hero + OG -> WebP
for (const name of ['hero', 'og']) {
  const jpg = path.join(pub, `${name}.jpg`)
  if (existsSync(jpg)) {
    await sharp(jpg).webp({ quality: 72 }).toFile(path.join(pub, `${name}.webp`))
    console.log('converted', name)
  }
}

// 3) Video poster frames (first frame) so videos can use preload="none"
let ffmpeg = true
try {
  execFileSync('ffmpeg', ['-version'], { stdio: 'ignore' })
} catch {
  ffmpeg = false
}
if (ffmpeg) {
  for (const v of ['jidar-video-1', 'jidar-video-2']) {
    const mp4 = path.join(galleryDir, `${v}.mp4`)
    if (existsSync(mp4)) {
      const frame = path.join(galleryDir, `${v}.frame.jpg`)
      execFileSync('ffmpeg', ['-y', '-i', mp4, '-vframes', '1', '-q:v', '4', frame], {
        stdio: 'ignore',
      })
      await sharp(frame)
        .resize(500, 500, { fit: 'cover', position: 'attention' })
        .webp({ quality: 68 })
        .toFile(path.join(galleryDir, `${v}.poster.webp`))
      console.log('poster', v)
    }
  }
} else {
  console.log('ffmpeg not found - skipping posters')
}
