import sharp from 'sharp'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const publicDir = path.join(__dirname, '..', 'public')
const source = path.join(publicDir, 'hero-wallpaper.png')

// Optimized hero for the LCP element (max 1920px wide, mozjpeg)
await sharp(source)
  .resize({ width: 1920, withoutEnlargement: true })
  .jpeg({ quality: 72, mozjpeg: true })
  .toFile(path.join(publicDir, 'hero.jpg'))

// Dedicated Open Graph image at 1200x630
await sharp(source)
  .resize({ width: 1200, height: 630, fit: 'cover', position: 'centre' })
  .jpeg({ quality: 80, mozjpeg: true })
  .toFile(path.join(publicDir, 'og.jpg'))

console.log('hero.jpg and og.jpg generated')
