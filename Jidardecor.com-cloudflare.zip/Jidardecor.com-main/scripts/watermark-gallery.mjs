import sharp from 'sharp'
import { readdir, readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'

const GALLERY_DIR = path.join(process.cwd(), 'public', 'gallery')
const WATERMARK_TEXT = 'jidardecor.com'
const MAX_WIDTH = 1600
const JPEG_QUALITY = 80

function escapeXml(s) {
  return s.replace(/[<>&'"]/g, (c) =>
    ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c])
  )
}

// Build an SVG watermark sized to the target image.
function buildWatermark(width, height) {
  const fontSize = Math.max(18, Math.round(width * 0.032))
  const padX = Math.round(fontSize * 0.9)
  const padY = Math.round(fontSize * 0.55)
  const textWidth = Math.round(WATERMARK_TEXT.length * fontSize * 0.56)
  const boxW = textWidth + padX * 2
  const boxH = fontSize + padY * 2
  const margin = Math.round(width * 0.02)
  const x = width - boxW - margin
  const y = height - boxH - margin
  const radius = Math.round(boxH * 0.28)

  const svg = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <g>
        <rect x="${x}" y="${y}" width="${boxW}" height="${boxH}" rx="${radius}" ry="${radius}"
          fill="black" fill-opacity="0.38"/>
        <text x="${x + boxW / 2}" y="${y + boxH / 2}"
          font-family="Arial, Helvetica, sans-serif" font-size="${fontSize}" font-weight="700"
          fill="white" fill-opacity="0.92" text-anchor="middle" dominant-baseline="central"
          letter-spacing="0.5">${escapeXml(WATERMARK_TEXT)}</text>
      </g>
    </svg>`
  return Buffer.from(svg)
}

const files = (await readdir(GALLERY_DIR)).filter((f) => /\.jpe?g$/i.test(f))

for (const file of files) {
  const filePath = path.join(GALLERY_DIR, file)
  const input = await readFile(filePath)
  const base = sharp(input).rotate() // respect EXIF orientation
  const meta = await base.metadata()

  const targetWidth = Math.min(meta.width || MAX_WIDTH, MAX_WIDTH)
  const resized = base.resize({ width: targetWidth, withoutEnlargement: true })
  const resizedMeta = await resized.clone().toBuffer({ resolveWithObject: true })
  const w = resizedMeta.info.width
  const h = resizedMeta.info.height

  const watermark = buildWatermark(w, h)

  const output = await sharp(resizedMeta.data)
    .composite([{ input: watermark, top: 0, left: 0 }])
    .jpeg({ quality: JPEG_QUALITY, mozjpeg: true })
    .toBuffer()

  await writeFile(filePath, output)
  console.log(`[v0] watermarked ${file} -> ${w}x${h}, ${(output.length / 1024).toFixed(0)}KB`)
}

console.log(`[v0] done. processed ${files.length} images.`)
