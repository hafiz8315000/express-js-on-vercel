// Cloudflare Pages Function — replaces app/api/quote/route.ts
// Runs at: POST /api/quote
// Set RESEND_API_KEY in: Cloudflare Pages → Settings → Environment variables

interface Env {
  RESEND_API_KEY?: string
}

const siteName = 'جدار ديكور'
const leadEmail = 'info@jidardecor.com'
const fromEmail = 'onboarding@resend.dev'

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
  })
}

function escapeHtml(str: string) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;')
}

export const onRequestPost: PagesFunction<Env> = async (context) => {
  try {
    const body = (await context.request.json()) as Record<string, unknown>
    const name = String(body.name || '').trim()
    const phone = String(body.phone || '').trim()
    const service = String(body.service || '').trim()
    const area = String(body.area || '').trim()
    const message = String(body.message || '').trim()

    if (!name || !phone) {
      return json({ error: 'الرجاء إدخال الاسم ورقم الجوال' }, 400)
    }

    const apiKey = context.env.RESEND_API_KEY
    if (!apiKey) {
      console.log('[quote] RESEND_API_KEY is not set — lead not emailed:', { name, phone })
      return json({ error: 'خدمة الإرسال غير مهيأة بعد. يرجى التواصل عبر الهاتف أو الواتساب.' }, 500)
    }

    const html = `
      <div dir="rtl" style="font-family: Arial, sans-serif; line-height: 1.8;">
        <h2>طلب عرض سعر جديد من ${siteName}</h2>
        <p><strong>الاسم:</strong> ${escapeHtml(name)}</p>
        <p><strong>رقم الجوال:</strong> ${escapeHtml(phone)}</p>
        <p><strong>نوع الخدمة:</strong> ${escapeHtml(service) || 'غير محدد'}</p>
        <p><strong>الحي / الموقع:</strong> ${escapeHtml(area) || 'غير محدد'}</p>
        <p><strong>تفاصيل إضافية:</strong><br/>${escapeHtml(message) || 'لا يوجد'}</p>
      </div>
    `

    const resendRes = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: `${siteName} <${fromEmail}>`,
        to: [leadEmail],
        reply_to: phone.includes('@') ? phone : undefined,
        subject: `طلب عرض سعر جديد - ${name}`,
        html,
      }),
    })

    if (!resendRes.ok) {
      const errText = await resendRes.text()
      console.log('[quote] Resend error:', errText)
      return json({ error: 'تعذّر إرسال الطلب حاليًا. حاول مرة أخرى أو تواصل معنا هاتفيًا.' }, 500)
    }

    return json({ ok: true })
  } catch (err) {
    console.log('[quote] Quote route error:', err)
    return json({ error: 'حدث خطأ غير متوقع' }, 500)
  }
}
