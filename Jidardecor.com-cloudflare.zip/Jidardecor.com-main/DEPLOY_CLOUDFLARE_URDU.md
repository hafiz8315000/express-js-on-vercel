# Cloudflare Pages per Deploy karne ka Tareeqa (Jidar Decor)

Is code mein maine ye changes kiye hain taake ye Vercel ki jagah Cloudflare Pages per chal sake:

1. `next.config.mjs` mein `output: 'export'` add kiya — ab site pura **static** banta hai (Cloudflare Pages sirf static/Functions support karta hai, Vercel jaisa Node server nahi).
2. `app/api/quote/route.ts` (jo quote form ka email bhejta tha) hata kar iski jagah `functions/api/quote.ts` banaya — ye Cloudflare "Pages Function" hai, bilkul wahi kaam karti hai (Resend se email bhejna), bas Cloudflare ke system per.
3. Form (`components/quote-form.tsx`) mein koi tabdeeli nahi ki — wo pehle jaisa `/api/quote` per hi request bhejta hai, aur Cloudflare khud-ba-khud usay `functions/api/quote.ts` per route kar dega.
4. `resend` package `package.json` se hata diya kyunke ab function seedha Resend ke API ko `fetch` se call karta hai (ye zyada reliable hai Cloudflare Workers per).
5. `pnpm-lock.yaml` hata kar `package-lock.json` rakha hai taake Cloudflare `npm` se install kare — koi lockfile mismatch na ho.

## GitHub per push karna

Apni existing GitHub repository (jo Vercel se linked hai) mein ye poora code push/replace kar dein:

```bash
git add -A
git commit -m "Cloudflare Pages ke liye migrate kiya (static export + Pages Function)"
git push
```

(Agar naya repo bana rahe hain to `git init` karke remote add karein.)

## Cloudflare Pages per Project banana

1. https://dash.cloudflare.com per jayein → **Workers & Pages** → **Create application** → **Pages** → **Connect to Git**.
2. Apni GitHub repository select karein.
3. Build settings mein ye set karein:
   - **Framework preset:** `Next.js (Static HTML Export)` (ya "None" bhi chalega)
   - **Build command:** `npm run build`
   - **Build output directory:** `out`
4. **Environment variables** mein add karein (Production aur Preview dono mein):
   - `RESEND_API_KEY` = apki Resend API key (jo pehle Vercel per set thi)
5. **Save and Deploy** per click karein.

Bas — pehli deploy ke baad Cloudflare aapko `xxxx.pages.dev` wala free URL dega, jo turant live hoga. Baad mein apna custom domain (`jidardecor.com`) **Custom domains** tab se add kar sakte hain (DNS Cloudflare per hona chahiye, ya CNAME add karein).

## Note

- Quote form (`RESEND_API_KEY` set hone ke baad) bilkul pehle jaisa email bhejega — koi frontend change nahi.
- Agar aap Vercel per bhi rakhna chahte hain (dono jagah), to `app/api/quote` wapis add karna hoga alag branch mein — lekin normally ek hi jagah (Cloudflare) per rakhna behtar hai taake confusion na ho.
