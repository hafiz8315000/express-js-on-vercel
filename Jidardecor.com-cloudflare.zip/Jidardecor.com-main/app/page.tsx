import { SiteHeader } from '@/components/site-header'
import { HeroSection } from '@/components/hero-section'
import { ServicesSection } from '@/components/services-section'
import { GallerySection } from '@/components/gallery-section'
import { WhyUsSection } from '@/components/why-us-section'
import { ProcessSection } from '@/components/process-section'
import { TestimonialsSection } from '@/components/testimonials-section'
import { FaqSection } from '@/components/faq-section'
import { QuoteForm } from '@/components/quote-form'
import { SiteFooter } from '@/components/site-footer'
import { FloatingContact } from '@/components/floating-contact'

export default function Page() {
  return (
    <>
      <SiteHeader />
      <main>
        <HeroSection />
        <ServicesSection />
        <GallerySection />
        <WhyUsSection />
        <ProcessSection />
        <TestimonialsSection />
        <FaqSection />
        <QuoteForm />
      </main>
      <SiteFooter />
      <FloatingContact />
    </>
  )
}
