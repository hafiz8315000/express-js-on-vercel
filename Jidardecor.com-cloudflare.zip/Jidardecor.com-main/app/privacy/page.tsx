import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { siteConfig, telHref } from '@/lib/site-config'

export const metadata: Metadata = {
  title: 'سياسة الخصوصية',
  description: `سياسة الخصوصية لموقع ${siteConfig.name} — كيف نجمع بياناتك ونستخدمها ونحميها عند طلب خدمات تركيب ورق الجدران بالرياض.`,
  alternates: { canonical: `${siteConfig.domain}/privacy` },
  robots: { index: true, follow: true },
}

const sections = [
  {
    title: 'البيانات التي نجمعها',
    body: 'عند تعبئة نموذج طلب عرض السعر، نجمع الاسم ورقم الجوال، وقد نجمع الحي أو الموقع وتفاصيل إضافية تختار مشاركتها. لا نطلب أي بيانات حساسة مثل الأرقام البنكية.',
  },
  {
    title: 'كيف نستخدم بياناتك',
    body: 'نستخدم بياناتك للتواصل معك بخصوص طلبك، وتحديد موعد المعاينة داخل الرياض، وتقديم عرض سعر، وتحسين جودة خدماتنا. لا نستخدم بياناتك لأي غرض آخر دون موافقتك.',
  },
  {
    title: 'مشاركة البيانات',
    body: 'لا نبيع أو نؤجر بياناتك الشخصية لأي طرف ثالث. قد نستعين بمزودي خدمات موثوقين (مثل خدمة إرسال البريد الإلكتروني) لمعالجة طلبك فقط، وفق سياسات خصوصية صارمة.',
  },
  {
    title: 'ملفات تعريف الارتباط والتحليلات',
    body: 'قد نستخدم أدوات تحليل لقياس أداء الموقع وتحسين تجربة الزوار. هذه الأدوات قد تجمع بيانات مجهولة الهوية مثل الصفحات التي تمت زيارتها ونوع الجهاز، دون تحديد هويتك الشخصية.',
  },
  {
    title: 'حماية البيانات',
    body: 'نتخذ إجراءات تقنية وتنظيمية معقولة لحماية بياناتك من الوصول غير المصرح به أو الفقدان أو إساءة الاستخدام.',
  },
  {
    title: 'حقوقك',
    body: 'يحق لك طلب الاطلاع على بياناتك أو تعديلها أو حذفها في أي وقت. للتواصل بشأن خصوصيتك يمكنك مراسلتنا عبر البريد الإلكتروني أو الاتصال بنا.',
  },
]

export default function PrivacyPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-16">
      <Link
        href="/"
        className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline"
      >
        <ArrowRight className="size-4" />
        العودة إلى الصفحة الرئيسية
      </Link>

      <h1 className="mt-6 text-3xl font-bold text-foreground md:text-4xl">سياسة الخصوصية</h1>
      <p className="mt-4 leading-relaxed text-muted-foreground">
        تُوضّح هذه السياسة كيفية تعامل {siteConfig.name} مع بياناتك الشخصية عند استخدامك
        لموقعنا أو طلب خدمات تركيب ورق الجدران في {siteConfig.city}. باستخدامك للموقع فإنك
        توافق على الممارسات الموضحة أدناه.
      </p>

      <div className="mt-10 space-y-8">
        {sections.map((section) => (
          <section key={section.title}>
            <h2 className="text-xl font-bold text-foreground">{section.title}</h2>
            <p className="mt-2 leading-relaxed text-muted-foreground">{section.body}</p>
          </section>
        ))}

        <section>
          <h2 className="text-xl font-bold text-foreground">التواصل معنا</h2>
          <p className="mt-2 leading-relaxed text-muted-foreground">
            لأي استفسار حول سياسة الخصوصية، تواصل معنا على البريد الإلكتروني{' '}
            <a href={`mailto:${siteConfig.leadEmail}`} className="text-primary hover:underline">
              {siteConfig.leadEmail}
            </a>{' '}
            أو عبر الهاتف{' '}
            <a href={telHref} className="text-primary hover:underline" dir="ltr">
              {siteConfig.phoneDisplay}
            </a>
            .
          </p>
        </section>
      </div>
    </main>
  )
}
