import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Cairo, Amiri } from 'next/font/google'
import Script from 'next/script'
import { GoogleContactConversion } from '@/components/google-contact-conversion'
import { siteConfig } from '@/lib/site-config'
import './globals.css'

const cairo = Cairo({
  subsets: ['arabic', 'latin'],
  variable: '--font-cairo',
  display: 'swap',
})

const amiri = Amiri({
  subsets: ['arabic', 'latin'],
  weight: ['400', '700'],
  variable: '--font-amiri',
  display: 'swap',
})

const title = `${siteConfig.name} | تركيب ورق جدران بالرياض - فني تركيب ورق حائط`
const description =
  'شركة تركيب ورق جدران بالرياض. توريد وتركيب ورق الحائط ثلاثي الأبعاد، أوراق فينيل، ديكورات جدران فاخرة للمنازل والمكاتب والمجالس. فني محترف، أسعار منافسة، وضمان على التركيب. اتصل الآن لعرض سعر مجاني.'

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.domain),
  title: {
    default: title,
    template: `%s | ${siteConfig.name}`,
  },
  description,
  applicationName: siteConfig.name,
  generator: 'v0.app',
  keywords: [
    'تركيب ورق جدران بالرياض',
    'ورق جدران الرياض',
    'فني تركيب ورق حائط',
    'ورق حائط ثلاثي الأبعاد',
    'ديكور جدران الرياض',
    'تركيب ورق حائط للمجالس',
    'محل ورق جدران بالرياض',
    'ورق جدران فاخر',
    'تركيب ورق جدران للغرف',
    'اسعار تركيب ورق الجدران بالرياض',
    'wallpaper installation Riyadh',
    'wallpaper contractor Riyadh',
  ],
  authors: [{ name: siteConfig.name }],
  creator: siteConfig.name,
  publisher: siteConfig.name,
  alternates: {
    canonical: siteConfig.domain,
  },
  openGraph: {
    type: 'website',
    locale: 'ar_SA',
    url: siteConfig.domain,
    title,
    description,
    siteName: siteConfig.name,
    images: [
      {
        url: '/og.jpg',
        width: 1200,
        height: 630,
        alt: 'تركيب ورق جدران فاخر بالرياض',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title,
    description,
    images: ['/og.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
      'max-snippet': -1,
      'max-video-preview': -1,
    },
  },
  category: 'business',
}

export const viewport: Viewport = {
  themeColor: '#c9a24b',
  colorScheme: 'light',
  width: 'device-width',
  initialScale: 1,
}

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'HomeAndConstructionBusiness',
  '@id': `${siteConfig.domain}/#business`,
  name: siteConfig.name,
  alternateName: siteConfig.nameEn,
  description,
  url: siteConfig.domain,
  telephone: siteConfig.phoneTel,
  image: `${siteConfig.domain}/og.jpg`,
  priceRange: 'SAR',
  areaServed: {
    '@type': 'City',
    name: siteConfig.cityEn,
  },
  address: {
    '@type': 'PostalAddress',
    addressLocality: siteConfig.cityEn,
    addressRegion: 'Riyadh Province',
    addressCountry: siteConfig.country,
  },
  geo: {
    '@type': 'GeoCoordinates',
    latitude: siteConfig.geo.latitude,
    longitude: siteConfig.geo.longitude,
  },
  openingHoursSpecification: {
    '@type': 'OpeningHoursSpecification',
    dayOfWeek: ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'],
    opens: '09:00',
    closes: '22:00',
  },
  makesOffer: {
    '@type': 'Offer',
    itemOffered: {
      '@type': 'Service',
      name: 'تركيب ورق الجدران',
      areaServed: siteConfig.cityEn,
    },
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ar" dir="rtl" className={`${cairo.variable} ${amiri.variable} bg-background`}>
      <body className="font-sans antialiased">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        {children}
        <GoogleContactConversion />
        <Script
          id="google-tag-loader"
          src="https://www.googletagmanager.com/gtag/js?id=AW-18314120705"
          strategy="beforeInteractive"
        />
        <Script id="google-tag-config" strategy="beforeInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'AW-18314120705');
          `}
        </Script>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
