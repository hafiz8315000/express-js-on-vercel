import type { Metadata } from 'next'
import Link from 'next/link'
import { BookOpen, ChevronLeft } from 'lucide-react'
import { BlogCard } from '@/components/blog-card'
import { SiteFooter } from '@/components/site-footer'
import { SiteHeader } from '@/components/site-header'
import { blogPosts } from '@/lib/blog'
import { siteConfig } from '@/lib/site-config'

export const metadata: Metadata = {
  title: 'مدونة ورق الجدران والديكور في الرياض',
  description: 'نصائح وأدلة من جدار ديكور حول اختيار وتركيب ورق الجدران وتجهيز الجدران والعناية بها في منازل ومكاتب الرياض.',
  alternates: { canonical: '/blog' },
  openGraph: {
    title: 'مدونة جدار ديكور | ورق الجدران في الرياض',
    description: 'أدلة عملية لاختيار وتركيب ورق الجدران والعناية به.',
    url: `${siteConfig.domain}/blog`,
    type: 'website',
  },
}

export default function BlogPage() {
  return (
    <>
      <SiteHeader />
      <main>
        <section className="border-b border-border bg-secondary/50 py-16 md:py-24">
          <div className="mx-auto max-w-6xl px-4">
            <nav aria-label="مسار التنقل" className="mb-8 flex items-center gap-2 text-sm text-muted-foreground">
              <Link href="/" className="hover:text-primary">الرئيسية</Link>
              <ChevronLeft className="size-4" />
              <span aria-current="page">المدونة</span>
            </nav>
            <div className="max-w-3xl">
              <span className="mb-5 inline-flex size-12 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <BookOpen className="size-6" />
              </span>
              <h1 className="text-balance font-serif text-4xl font-bold leading-tight text-foreground md:text-6xl">دليلك إلى ورق الجدران والديكور</h1>
              <p className="mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-muted-foreground">مقالات عملية تساعدك على اختيار الخامة المناسبة، تجهيز الجدار، والحصول على تركيب احترافي يدوم طويلًا في منزلك أو مكتبك بالرياض.</p>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-20">
          <div className="mx-auto max-w-6xl px-4">
            <div className="mb-10 flex items-end justify-between gap-4">
              <div>
                <p className="text-sm font-bold text-primary">أحدث الأدلة</p>
                <h2 className="mt-2 font-serif text-3xl font-bold text-foreground">مقالات مختارة</h2>
              </div>
              <span className="text-sm text-muted-foreground">{blogPosts.length} مقالات</span>
            </div>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {blogPosts.map((post) => <BlogCard key={post.slug} post={post} />)}
            </div>
          </div>
        </section>

        <section className="border-y border-border bg-primary py-12 text-primary-foreground">
          <div className="mx-auto flex max-w-6xl flex-col items-start gap-5 px-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="font-serif text-3xl font-bold">هل تحتاج إلى معاينة لجدارك؟</h2>
              <p className="mt-2 leading-relaxed text-primary-foreground/80">تواصل معنا للحصول على استشارة وقياس مجاني داخل الرياض.</p>
            </div>
            <Link href="/#quote" className="rounded-xl bg-background px-6 py-3 font-bold text-foreground transition-transform hover:scale-[1.02]">اطلب عرض سعر</Link>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  )
}
