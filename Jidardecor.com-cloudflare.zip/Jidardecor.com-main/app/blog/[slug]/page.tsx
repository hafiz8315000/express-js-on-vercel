import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ChevronLeft, Clock3, CalendarDays, Check, Phone } from 'lucide-react'
import { ArticleShare } from '@/components/article-share'
import { BlogCard } from '@/components/blog-card'
import { SiteFooter } from '@/components/site-footer'
import { SiteHeader } from '@/components/site-header'
import { blogPosts, formatArabicDate, getBlogPost } from '@/lib/blog'
import { siteConfig, telHref, whatsappHref } from '@/lib/site-config'

type Props = { params: Promise<{ slug: string }> }

export function generateStaticParams() {
  return blogPosts.map(({ slug }) => ({ slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const post = getBlogPost(slug)
  if (!post) return {}
  const url = `${siteConfig.domain}/blog/${post.slug}`
  return {
    title: post.title,
    description: post.description,
    keywords: post.keywords,
    alternates: { canonical: url },
    openGraph: { title: post.title, description: post.description, url, type: 'article', publishedTime: post.publishedAt, modifiedTime: post.updatedAt, images: [{ url: post.image, alt: post.imageAlt }] },
    twitter: { card: 'summary_large_image', title: post.title, description: post.description, images: [post.image] },
  }
}

export default async function ArticlePage({ params }: Props) {
  const { slug } = await params
  const post = getBlogPost(slug)
  if (!post) notFound()

  const url = `${siteConfig.domain}/blog/${post.slug}`
  const related = blogPosts.filter((item) => item.slug !== post.slug).slice(0, 2)
  const articleSchema = {
    '@context': 'https://schema.org', '@type': 'Article', headline: post.title, description: post.description,
    image: `${siteConfig.domain}${post.image}`, datePublished: post.publishedAt, dateModified: post.updatedAt,
    author: { '@type': 'Organization', name: siteConfig.name, url: siteConfig.domain },
    publisher: { '@type': 'Organization', name: siteConfig.name, url: siteConfig.domain }, mainEntityOfPage: url,
  }
  const breadcrumbSchema = {
    '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'الرئيسية', item: siteConfig.domain },
      { '@type': 'ListItem', position: 2, name: 'المدونة', item: `${siteConfig.domain}/blog` },
      { '@type': 'ListItem', position: 3, name: post.title, item: url },
    ],
  }
  const faqSchema = { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: post.faqs.map((faq) => ({ '@type': 'Question', name: faq.question, acceptedAnswer: { '@type': 'Answer', text: faq.answer } })) }

  return (
    <>
      <SiteHeader />
      <main>
        <article>
          <header className="border-b border-border bg-secondary/40 py-12 md:py-16">
            <div className="mx-auto max-w-5xl px-4">
              <nav aria-label="مسار التنقل" className="mb-8 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                <Link href="/" className="hover:text-primary">الرئيسية</Link><ChevronLeft className="size-4" />
                <Link href="/blog" className="hover:text-primary">المدونة</Link><ChevronLeft className="size-4" />
                <span aria-current="page" className="line-clamp-1">{post.title}</span>
              </nav>
              <span className="rounded-full bg-primary/10 px-3 py-1 text-sm font-bold text-primary">{post.category}</span>
              <h1 className="mt-5 max-w-4xl text-balance font-serif text-4xl font-bold leading-tight text-foreground md:text-6xl">{post.title}</h1>
              <p className="mt-5 max-w-3xl text-pretty text-lg leading-relaxed text-muted-foreground">{post.excerpt}</p>
              <div className="mt-6 flex flex-wrap items-center gap-5 text-sm text-muted-foreground">
                <span className="inline-flex items-center gap-2"><CalendarDays className="size-4" />{formatArabicDate(post.publishedAt)}</span>
                <span className="inline-flex items-center gap-2"><Clock3 className="size-4" />{post.readingMinutes} دقائق قراءة</span>
                <span>إعداد فريق {siteConfig.name}</span>
              </div>
            </div>
          </header>

          <div className="mx-auto max-w-6xl px-4 py-10 md:py-14">
            <Image src={post.image} alt={post.imageAlt} width={1400} height={900} priority className="max-h-[560px] w-full rounded-2xl object-cover shadow-sm" sizes="(max-width: 1200px) 100vw, 1152px" />
            <div className="mt-12 grid gap-10 lg:grid-cols-[240px_minmax(0,1fr)]">
              <aside className="lg:sticky lg:top-24 lg:self-start">
                <div className="rounded-2xl border border-border bg-card p-5">
                  <p className="font-bold text-card-foreground">محتويات المقال</p>
                  <ol className="mt-4 flex flex-col gap-3 text-sm text-muted-foreground">
                    {post.sections.map((section, index) => <li key={section.id}><a href={`#${section.id}`} className="hover:text-primary">{index + 1}. {section.title}</a></li>)}
                    <li><a href="#faq" className="hover:text-primary">{post.sections.length + 1}. الأسئلة الشائعة</a></li>
                  </ol>
                </div>
              </aside>

              <div className="min-w-0">
                <div className="flex flex-col gap-10">
                  {post.sections.map((section) => (
                    <section key={section.id} id={section.id} className="scroll-mt-24">
                      <h2 className="text-balance font-serif text-3xl font-bold text-foreground">{section.title}</h2>
                      {section.paragraphs?.map((paragraph) => <p key={paragraph} className="mt-4 text-pretty text-lg leading-8 text-muted-foreground">{paragraph}</p>)}
                      {section.items && <ul className="mt-5 grid gap-3 sm:grid-cols-2">{section.items.map((item) => <li key={item} className="flex items-start gap-3 rounded-xl bg-secondary/60 p-4 leading-relaxed text-foreground"><Check className="mt-1 size-4 shrink-0 text-primary" />{item}</li>)}</ul>}
                    </section>
                  ))}
                </div>

                <section id="faq" className="mt-12 scroll-mt-24 border-t border-border pt-10">
                  <h2 className="font-serif text-3xl font-bold text-foreground">الأسئلة الشائعة</h2>
                  <div className="mt-6 flex flex-col gap-4">{post.faqs.map((faq) => <details key={faq.question} className="group rounded-xl border border-border bg-card p-5"><summary className="cursor-pointer font-bold text-card-foreground">{faq.question}</summary><p className="mt-3 leading-relaxed text-muted-foreground">{faq.answer}</p></details>)}</div>
                </section>

                <div className="mt-10 border-y border-border py-6"><ArticleShare title={post.title} /></div>
                <section className="mt-10 rounded-2xl bg-primary p-6 text-primary-foreground md:p-8">
                  <h2 className="font-serif text-3xl font-bold">استشارة وقياس مجاني داخل الرياض</h2>
                  <p className="mt-3 max-w-2xl leading-relaxed text-primary-foreground/80">أرسل صور الجدار عبر واتساب أو اتصل بنا لتحديد موعد المعاينة والحصول على عرض سعر واضح.</p>
                  <div className="mt-6 flex flex-wrap gap-3">
                    <a href={whatsappHref} target="_blank" rel="noopener noreferrer" className="rounded-xl bg-[#25D366] px-5 py-3 font-bold text-white">تواصل عبر واتساب</a>
                    <a href={telHref} className="inline-flex items-center gap-2 rounded-xl bg-background px-5 py-3 font-bold text-foreground"><Phone className="size-4" />اتصل الآن</a>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </article>

        <section className="border-t border-border bg-secondary/40 py-16">
          <div className="mx-auto max-w-6xl px-4"><h2 className="mb-8 font-serif text-3xl font-bold text-foreground">مقالات ذات صلة</h2><div className="grid gap-6 md:grid-cols-2">{related.map((item) => <BlogCard key={item.slug} post={item} />)}</div></div>
        </section>
      </main>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <SiteFooter />
    </>
  )
}
