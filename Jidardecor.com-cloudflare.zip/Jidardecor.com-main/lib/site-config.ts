// ============================================================================
//  إعدادات الموقع — عدّل هذا الملف فقط لتغيير أرقام التواصل وبيانات النشاط
//  SITE SETTINGS — Edit ONLY this file to change your contact numbers & info
// ============================================================================

export const siteConfig = {
  // ---- اسم الموقع والدومين / Site name & domain ----
  name: "جدار ديكور",
  nameEn: "Jidar Decor",
  domain: "https://jidardecor.com",

  // ---- رقم الجوال والواتساب / Phone & WhatsApp number ----
  // ⚠️ استبدل هذا الرقم برقمك الحقيقي / Replace with your REAL number
  // للاتصال: بصيغة محلية / For calling: local format
  phoneDisplay: "0571080854",
  // للاتصال (tel:) بصيغة دولية بدون + / For tel: international format
  phoneTel: "+966571080854",
  // للواتساب: بصيغة دولية بدون + أو أصفار / For WhatsApp: intl digits only
  whatsapp: "966571080854",

  // ---- البريد الإلكتروني لاستقبال الطلبات / Email to receive leads ----
  // ⚠️ استبدل ببريدك / Replace with YOUR email
  leadEmail: "info@jidardecor.com",
  // البريد المُرسِل — يجب توثيق الدومين في Resend / Verified sender in Resend
  fromEmail: "onboarding@resend.dev",

  // ---- المدينة والمنطقة / City & region ----
  city: "الرياض",
  cityEn: "Riyadh",
  region: "منطقة الرياض",
  country: "SA",

  // ---- ساعات العمل / Working hours ----
  hours: "السبت - الخميس: 9 صباحًا - 10 مساءً",

  // ---- رسالة الواتساب الافتراضية / Default WhatsApp prefilled message ----
  whatsappMessage: "مرحبًا، أرغب في الاستفسار عن خدمات تركيب ورق الجدران.",

  // ---- روابط التواصل الاجتماعي (اختياري) / Social links (optional) ----
  social: {
    instagram: "",
    twitter: "",
    tiktok: "",
    snapchat: "",
  },

  // ---- الإحداثيات الجغرافية للرياض / Geo coordinates (Riyadh) ----
  geo: {
    latitude: 24.7136,
    longitude: 46.6753,
  },
} as const

// روابط جاهزة للاستخدام / Ready-to-use links
export const telHref = `tel:${siteConfig.phoneTel}`
export const whatsappHref = `https://wa.me/${siteConfig.whatsapp}?text=${encodeURIComponent(
  siteConfig.whatsappMessage,
)}`
