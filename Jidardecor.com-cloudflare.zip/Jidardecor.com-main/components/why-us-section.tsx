import { ShieldCheck, Clock, BadgeDollarSign, MapPin, ThumbsUp, Wrench } from 'lucide-react'
import { siteConfig } from '@/lib/site-config'

const reasons = [
  { icon: Wrench, title: 'فنيون متخصصون', desc: 'خبرة سنوات في تركيب جميع أنواع ورق الجدران باحترافية.' },
  { icon: ShieldCheck, title: 'ضمان على العمل', desc: 'نضمن جودة التركيب وعدم ظهور فقاعات أو تجاعيد.' },
  { icon: BadgeDollarSign, title: 'أسعار منافسة', desc: 'أفضل الأسعار في الرياض بدون أي رسوم خفية.' },
  { icon: Clock, title: 'التزام بالمواعيد', desc: 'ننجز العمل في الوقت المتفق عليه وبنظافة تامة.' },
  { icon: MapPin, title: 'نغطي كامل الرياض', desc: 'خدمة سريعة تصل إلى جميع أحياء مدينة الرياض.' },
  { icon: ThumbsUp, title: 'رضا العملاء', desc: 'مئات العملاء السعداء يوصون بخدماتنا.' },
]

export function WhyUsSection() {
  return (
    <section id="why-us" className="py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-3xl font-bold text-foreground md:text-4xl">
            لماذا تختار {siteConfig.name} لتركيب ورق الجدران؟
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            نجمع بين الخبرة والجودة والسعر المناسب لنقدم لك تجربة تركيب ورق جدران
            لا مثيل لها في الرياض.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {reasons.map((r) => (
            <div key={r.title} className="flex gap-4 rounded-2xl bg-secondary/40 p-6">
              <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <r.icon className="size-5" />
              </div>
              <div>
                <h3 className="font-bold text-foreground">{r.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{r.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
