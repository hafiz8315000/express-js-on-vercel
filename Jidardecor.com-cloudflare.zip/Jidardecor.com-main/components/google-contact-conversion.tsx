'use client'

import { useEffect } from 'react'

const CONVERSION_DESTINATION = 'AW-18314120705/8zsmCITN0c4cEIGc7ZxE'

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void
  }
}

function isContactLink(link: HTMLAnchorElement) {
  const href = link.getAttribute('href') ?? ''
  return href.startsWith('tel:') || href.startsWith('https://wa.me/')
}

export function GoogleContactConversion() {
  useEffect(() => {
    function trackContactClick(event: MouseEvent) {
      if (!(event.target instanceof Element)) return

      const link = event.target.closest('a')
      if (!(link instanceof HTMLAnchorElement) || !isContactLink(link)) return

      const href = link.href
      const isPhoneLink = href.startsWith('tel:')
      let navigated = false

      const continueToPhone = () => {
        if (!isPhoneLink || navigated) return
        navigated = true
        window.location.href = href
      }

      if (isPhoneLink) event.preventDefault()

      if (typeof window.gtag !== 'function') {
        continueToPhone()
        return
      }

      window.gtag('event', 'conversion', {
        send_to: CONVERSION_DESTINATION,
        event_callback: continueToPhone,
        event_timeout: 1500,
      })

      if (isPhoneLink) window.setTimeout(continueToPhone, 1600)
    }

    document.addEventListener('click', trackContactClick, { capture: true })
    return () => document.removeEventListener('click', trackContactClick, { capture: true })
  }, [])

  return null
}
