'use client'

import { useState, useEffect } from 'react'
import { Phone, Menu, X } from 'lucide-react'
import { siteConfig, telHref } from '@/lib/site-config'
import { buttonVariants } from '@/components/ui/button'

const navLinks = [
  { href: '#services', label: 'خدماتنا' },
  { href: '#gallery', label: 'أعمالنا' },
  { href: '#why-us', label: 'لماذا نحن' },
  { href: '#faq', label: 'الأسئلة الشائعة' },
  { href: '#quote', label: 'طلب عرض سعر' },
]

export function SiteHeader() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10)
    onScroll()
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-colors ${
        scrolled ? 'bg-background/95 shadow-sm backdrop-blur' : 'bg-background/80 backdrop-blur'
      }`}
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4">
        <a href="#home" className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary font-serif text-lg font-bold text-primary-foreground">
            ج
          </span>
          <span className="text-lg font-bold text-foreground">{siteConfig.name}</span>
        </a>

        <nav className="hidden items-center gap-6 lg:flex" aria-label="التنقل الرئيسي">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden lg:block">
          <a href={telHref} className={buttonVariants({ size: 'lg', className: 'h-11 px-5' })}>
            <Phone className="size-4" />
            اتصل الآن
          </a>
        </div>

        <button
          type="button"
          className="inline-flex items-center justify-center rounded-md p-2 text-foreground lg:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? 'إغلاق القائمة' : 'فتح القائمة'}
          aria-expanded={open}
        >
          {open ? <X className="size-6" /> : <Menu className="size-6" />}
        </button>
      </div>

      {open && (
        <nav
          className="border-t border-border bg-background lg:hidden"
          aria-label="التنقل للجوال"
        >
          <div className="mx-auto flex max-w-6xl flex-col px-4 py-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="rounded-md px-2 py-3 text-sm font-medium text-foreground hover:bg-secondary"
                onClick={() => setOpen(false)}
              >
                {link.label}
              </a>
            ))}
            <a
              href={telHref}
              className={buttonVariants({ size: 'lg', className: 'my-2 h-11' })}
              onClick={() => setOpen(false)}
            >
              <Phone className="size-4" />
              اتصل الآن {siteConfig.phoneDisplay}
            </a>
          </div>
        </nav>
      )}
    </header>
  )
}
