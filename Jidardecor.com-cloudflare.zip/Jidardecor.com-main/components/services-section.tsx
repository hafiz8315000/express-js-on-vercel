import { Layers, Home, Building2, Baby, Sparkles, Ruler } from 'lucide-react'

const services = [
  {
    icon: Layers,
    title: 'ورق جدران ثلاثي الأبعاد',
    desc: 'تصاميم 3D عصرية تضيف عمقًا وفخامة لجدران منزلك ومجلسك.',
  },
  {
    icon: Home,
    title: 'تركيب لغرف المنزل',
    desc: 'ورق حائط لغرف النوم والصالات والمجالس بجودة عالية وتشطيب مثالي.',
  },
  {
    icon: Building2,
    title: 'المكاتب والمحلات',
    desc: 'حلول ديكور احترافية للمكاتب والشركات والمحلات التجارية بالرياض.',
  },
  {
    icon: Baby,
    title: 'غرف الأطفال',
    desc: 'رسومات وأوراق جدران مبهجة وآمنة تناسب غرف الأطفال.',
  },
  {
    icon: Sparkles,
    title: 'أوراق فينيل قابلة للغسل',
    desc: 'خامات فينيل مقاومة للرطوبة وسهلة التنظيف تدوم طويلًا.',
  },
  {
    icon: Ruler,
    title: 'معاينة وقياس مجاني',
    desc: 'نزور موقعك داخل الرياض للقياس وتقديم عرض سعر دقيق مجانًا.',
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-3xl font-bold text-foreground md:text-4xl">
            خدمات تركيب ورق الجدران بالرياض
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            نقدم مجموعة متكاملة من خدمات توريد وتركيب ورق الحائط بأحدث التصاميم
            وأجود الخامات، وبأيدي فنيين متخصصين في مدينة الرياض.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <article
              key={service.title}
              className="rounded-2xl border border-border bg-card p-6 transition-shadow hover:shadow-md"
            >
              <div className="flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <service.icon className="size-6" />
              </div>
              <h3 className="mt-4 text-lg font-bold text-card-foreground">
                {service.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {service.desc}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
