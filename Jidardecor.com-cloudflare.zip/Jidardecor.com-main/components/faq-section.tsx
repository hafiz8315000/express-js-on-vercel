const faqs = [
  {
    q: 'كم تبلغ تكلفة تركيب ورق الجدران في الرياض؟',
    a: 'تعتمد التكلفة على المساحة ونوع ورق الجدران المختار. نقدم معاينة وعرض سعر مجاني داخل الرياض حتى تحصل على تكلفة دقيقة قبل البدء.',
  },
  {
    q: 'هل تقدمون خدمة توريد ورق الجدران أم التركيب فقط؟',
    a: 'نقدم الخدمتين معًا؛ يمكننا توريد ورق الجدران بأحدث التصاميم وأجود الخامات، كما نركّب الورق الذي يوفره العميل أيضًا.',
  },
  {
    q: 'كم يستغرق تركيب ورق الجدران؟',
    a: 'غالبًا يُنجز تركيب الغرفة الواحدة خلال ساعات قليلة في نفس اليوم، حسب المساحة وحالة الجدران.',
  },
  {
    q: 'هل تغطون جميع أحياء مدينة الرياض؟',
    a: 'نعم، نقدم خدمة تركيب ورق الجدران في جميع أحياء الرياض شمالها وجنوبها وشرقها وغربها.',
  },
  {
    q: 'هل يوجد ضمان على التركيب؟',
    a: 'نعم، نقدم ضمانًا على جودة التركيب لضمان عدم ظهور فقاعات أو انفصال في الأطراف عند التركيب السليم.',
  },
]

const faqJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: faqs.map((f) => ({
    '@type': 'Question',
    name: f.q,
    acceptedAnswer: { '@type': 'Answer', text: f.a },
  })),
}

export function FaqSection() {
  return (
    <section id="faq" className="bg-secondary/40 py-20">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <div className="mx-auto max-w-3xl px-4">
        <div className="text-center">
          <h2 className="text-balance text-3xl font-bold text-foreground md:text-4xl">
            الأسئلة الشائعة
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            إجابات على أكثر الأسئلة تكرارًا حول خدمات تركيب ورق الجدران بالرياض.
          </p>
        </div>

        <div className="mt-10 space-y-4">
          {faqs.map((faq) => (
            <details
              key={faq.q}
              className="group rounded-xl border border-border bg-card p-5 [&_summary::-webkit-details-marker]:hidden"
            >
              <summary className="flex cursor-pointer items-center justify-between gap-4 font-bold text-card-foreground">
                {faq.q}
                <span className="text-primary transition-transform group-open:rotate-45">
                  +
                </span>
              </summary>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{faq.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  )
}
