import Link from 'next/link'
import { Phone, MapPin, Clock, MessageCircle } from 'lucide-react'
import { siteConfig, telHref, whatsappHref } from '@/lib/site-config'

export function SiteFooter() {
  const year = new Date().getFullYear()
  return (
    <footer className="border-t border-border bg-secondary/40">
      <div className="mx-auto max-w-6xl px-4 py-12">
        <div className="grid gap-8 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary font-serif text-lg font-bold text-primary-foreground">
                ج
              </span>
              <span className="text-lg font-bold text-foreground">{siteConfig.name}</span>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
              معلم متخصص في توريد وتركيب ورق الجدران الفاخر بجميع أنواعه في مدينة
              الرياض. جودة عالية، أسعار منافسة، وضمان على التركيب.
            </p>
          </div>

          <div>
            <h3 className="font-bold text-foreground">روابط سريعة</h3>
            <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
              <li><a href="#services" className="hover:text-primary">خدماتنا</a></li>
              <li><a href="#gallery" className="hover:text-primary">أعمالنا</a></li>
              <li><a href="#why-us" className="hover:text-primary">لماذا نحن</a></li>
              <li><a href="#faq" className="hover:text-primary">الأسئلة الشائعة</a></li>
              <li><a href="#quote" className="hover:text-primary">طلب عرض سعر</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-foreground">تواصل معنا</h3>
            <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <Phone className="size-4 text-primary" />
                <a href={telHref} className="hover:text-primary" dir="ltr">
                  {siteConfig.phoneDisplay}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="size-4 text-primary" />
                <span>{siteConfig.city}، المملكة العربية السعودية</span>
              </li>
              <li className="flex items-center gap-2">
                <Clock className="size-4 text-primary" />
                <span>{siteConfig.hours}</span>
              </li>
              <li>
                <a
                  href={whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-lg bg-[#25D366] px-4 py-2 font-medium text-white transition-colors hover:bg-[#1eb959]"
                >
                  <MessageCircle className="size-4" />
                  تواصل عبر الواتساب
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center gap-3 border-t border-border pt-6 text-center text-xs text-muted-foreground sm:flex-row sm:justify-between">
          <span>© {year} {siteConfig.name} — جميع الحقوق محفوظة. تركيب ورق جدران بالرياض.</span>
          <Link href="/privacy" className="hover:text-primary">
            سياسة الخصوصية
          </Link>
        </div>
      </div>
    </footer>
  )
}
