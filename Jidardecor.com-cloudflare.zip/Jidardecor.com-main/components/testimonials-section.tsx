import { Star } from 'lucide-react'

const reviews = [
  {
    name: 'عبدالله المطيري',
    area: 'حي النرجس، الرياض',
    text: 'تركيب احترافي ونظيف، الفني على مستوى عالٍ من الدقة. ورق الجدران غيّر شكل المجلس بالكامل. أنصح بهم بشدة.',
  },
  {
    name: 'نورة العتيبي',
    area: 'حي الياسمين، الرياض',
    text: 'خدمة ممتازة من المعاينة حتى التركيب، التزموا بالموعد والسعر كان مناسب جدًا. النتيجة فاقت توقعاتي.',
  },
  {
    name: 'فيصل الدوسري',
    area: 'حي قرطبة، الرياض',
    text: 'أفضل شركة تركيب ورق جدران تعاملت معها بالرياض. تشطيب مثالي وبدون أي فقاعات. شكرًا لكم.',
  },
]

export function TestimonialsSection() {
  return (
    <section className="py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-3xl font-bold text-foreground md:text-4xl">
            آراء عملائنا في الرياض
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            ثقة عملائنا هي أساس نجاحنا. إليك بعض تجاربهم مع خدمات تركيب ورق الجدران.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {reviews.map((review) => (
            <figure key={review.name} className="rounded-2xl border border-border bg-card p-6">
              <div className="flex gap-1 text-primary">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="size-4 fill-current" />
                ))}
              </div>
              <blockquote className="mt-4 text-sm leading-relaxed text-card-foreground">
                {review.text}
              </blockquote>
              <figcaption className="mt-4 border-t border-border pt-4">
                <span className="block font-bold text-foreground">{review.name}</span>
                <span className="text-xs text-muted-foreground">{review.area}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}
