'use client'

import { useCallback, useEffect, useState } from 'react'
import Image from 'next/image'
import { ChevronLeft, ChevronRight, X, ZoomIn } from 'lucide-react'

const galleryImages = [
  { src: '/gallery/jidar6', alt: 'تركيب ورق جدران بنقشة أشجار كلاسيكية بدرجات الوردي في الرياض' },
  { src: '/gallery/jidar15', alt: 'ورق جدران ثلاثي الأبعاد بمنظر غابة وغزلان لغرفة نوم في الرياض' },
  { src: '/gallery/jidar13', alt: 'ورق جدران أطفال بنقشة غابة وحيوانات في الرياض' },
  { src: '/gallery/jidar10', alt: 'ورق جدران بمنظر غابة ضبابية مع إضاءة مخفية في الرياض' },
  { src: '/gallery/jidar7', alt: 'ورق جدران فاخر ثلاثي الأبعاد بنقشة طائر وزهور في الرياض' },
  { src: '/gallery/jidar9', alt: 'تركيب ورق جدران بمنظر أشجار استوائية لممر المنزل في الرياض' },
  { src: '/gallery/jidar11', alt: 'ورق جدران بمنظر غابة مع إضاءة ووحدة خشبية في الرياض' },
  { src: '/gallery/jidar8b', alt: 'ورق جدران بمنظر طائر مالك الحزين وإضاءة مخفية في الرياض' },
  { src: '/gallery/jidar2', alt: 'ورق جدران بنقشة زهور كلاسيكية لغرفة نوم في الرياض' },
  { src: '/gallery/jidar1', alt: 'ورق جدران بنقشة زهور فاتحة لجدار مميز في الرياض' },
  { src: '/gallery/jidar4', alt: 'ورق جدران بمنظر شجرة كلاسيكية بدرجات البني في الرياض' },
  { src: '/gallery/jidar12', alt: 'ورق جدران للسقف بلوحة فنية كلاسيكية في الرياض' },
  { src: '/gallery/jidar3', alt: 'ورق جدران بملمس حجري طبيعي مع قواطع خشبية في الرياض' },
  { src: '/gallery/jidar8a', alt: 'تركيب ورق جدران بمنظر شجرة وبحيرة بدرجات الوردي في الرياض' },
  { src: '/gallery/jidar19', alt: 'ورق جدران أطفال بنقشة طبيعية مبهجة مع دهان أخضر لغرفة أطفال في الرياض' },
  { src: '/gallery/jidar20', alt: 'ورق جدران بمنظر أشجار موز استوائية بدرجات الأخضر في الرياض' },
  { src: '/gallery/jidar16', alt: 'تصميم جداري بأقواس هندسية بدرجات الأخضر الزيتوني في الرياض' },
  { src: '/gallery/jidar23', alt: 'دهان جداري بأقواس خضراء متدرجة لغرفة في الرياض' },
  { src: '/gallery/jidar22', alt: 'جدار مايكروسمنت بتأثير خرساني رمادي مع إضاءة معلقة في الرياض' },
  { src: '/gallery/jidar18', alt: 'جدار أزرق فاتح مع أعمدة مضلعة وإضاءة LED مخفية في الرياض' },
  { src: '/gallery/jidar21', alt: 'تفصيل عمود ديكوري مضلع بإضاءة LED خلفية في الرياض' },
  { src: '/gallery/jidar17', alt: 'لقطة بانورامية لديكورات جدارية متنوعة من أعمالنا في الرياض' },
]

const galleryVideos = [
  { src: '/gallery/jidar-video-1.mp4', label: 'من أعمال تركيب ورق الجدران في الرياض' },
  { src: '/gallery/jidar-video-2.mp4', label: 'مشروع تركيب ورق جدران في الرياض' },
]

export function GallerySection() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null)
  const isOpen = activeIndex !== null

  const close = useCallback(() => setActiveIndex(null), [])
  const next = useCallback(
    () => setActiveIndex((i) => (i === null ? i : (i + 1) % galleryImages.length)),
    [],
  )
  const prev = useCallback(
    () =>
      setActiveIndex((i) =>
        i === null ? i : (i - 1 + galleryImages.length) % galleryImages.length,
      ),
    [],
  )

  useEffect(() => {
    if (!isOpen) return
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') close()
      // RTL: ArrowRight -> previous, ArrowLeft -> next
      if (e.key === 'ArrowRight') prev()
      if (e.key === 'ArrowLeft') next()
    }
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [isOpen, close, next, prev])

  const active = activeIndex !== null ? galleryImages[activeIndex] : null

  return (
    <section id="gallery" className="bg-secondary/40 py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-3xl font-bold text-foreground md:text-4xl">
            نماذج من أعمالنا في الرياض
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            صور وفيديوهات حقيقية من مشاريع تركيب ورق الجدران التي نفذناها لعملائنا
            في مختلف أحياء مدينة الرياض. اضغط على أي صورة لعرضها بالحجم الكامل.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {galleryVideos.map((video) => (
            <figure
              key={video.src}
              className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
            >
              <video
                src={video.src}
                controls
                playsInline
                preload="none"
                className="aspect-square w-full bg-secondary object-cover"
                aria-label={video.label}
              />
              <figcaption className="px-4 py-3 text-sm leading-relaxed text-muted-foreground">
                {video.label}
              </figcaption>
            </figure>
          ))}
          {galleryImages.map((image, index) => (
            <figure
              key={image.src}
              className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm"
            >
              <button
                type="button"
                onClick={() => setActiveIndex(index)}
                className="group relative block w-full cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                aria-label={`عرض الصورة بالحجم الكامل: ${image.alt}`}
              >
                <Image
                  src={`${image.src}.thumb.webp`}
                  alt={image.alt}
                  width={500}
                  height={500}
                  loading="lazy"
                  className="aspect-square w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                />
                <span className="absolute inset-0 flex items-center justify-center bg-foreground/0 opacity-0 transition-all duration-300 group-hover:bg-foreground/30 group-hover:opacity-100">
                  <ZoomIn className="size-8 text-white" aria-hidden="true" />
                </span>
              </button>
              <figcaption className="px-4 py-3 text-sm leading-relaxed text-muted-foreground">
                {image.alt}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>

      {isOpen && active && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="معرض الصور"
          className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/90 p-4"
          onClick={close}
        >
          <button
            type="button"
            onClick={close}
            aria-label="إغلاق"
            className="absolute right-4 top-4 rounded-full bg-background/10 p-2 text-white transition-colors hover:bg-background/20"
          >
            <X className="size-6" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation()
              prev()
            }}
            aria-label="الصورة السابقة"
            className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full bg-background/10 p-2 text-white transition-colors hover:bg-background/20 sm:right-8"
          >
            <ChevronRight className="size-7" aria-hidden="true" />
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation()
              next()
            }}
            aria-label="الصورة التالية"
            className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full bg-background/10 p-2 text-white transition-colors hover:bg-background/20 sm:left-8"
          >
            <ChevronLeft className="size-7" aria-hidden="true" />
          </button>

          <figure
            className="flex max-h-[90vh] max-w-4xl flex-col items-center"
            onClick={(e) => e.stopPropagation()}
          >
            <Image
              src={`${active.src}.webp`}
              alt={active.alt}
              width={1400}
              height={1400}
              className="h-auto max-h-[80vh] w-auto rounded-lg object-contain"
              sizes="90vw"
            />
            <figcaption className="mt-4 max-w-2xl text-center text-sm leading-relaxed text-white/90">
              {active.alt}
            </figcaption>
          </figure>
        </div>
      )}
    </section>
  )
}
