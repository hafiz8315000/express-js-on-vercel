const steps = [
  { num: '١', title: 'تواصل معنا', desc: 'اتصل أو راسلنا عبر الواتساب لطلب الخدمة.' },
  { num: '٢', title: 'المعاينة والقياس', desc: 'نزور موقعك داخل الرياض للقياس ومساعدتك في اختيار التصميم.' },
  { num: '٣', title: 'عرض السعر', desc: 'نقدم لك عرض سعر واضح ومفصل بدون أي التزام.' },
  { num: '٤', title: 'التركيب الاحترافي', desc: 'يقوم فريقنا بالتركيب بدقة ونظافة وفي الوقت المحدد.' },
]

export function ProcessSection() {
  return (
    <section className="bg-secondary/40 py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-balance text-3xl font-bold text-foreground md:text-4xl">
            كيف نعمل؟ خطوات بسيطة
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            من أول اتصال حتى تسليم العمل، نجعل عملية تركيب ورق الجدران سهلة ومريحة.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step) => (
            <div key={step.num} className="relative rounded-2xl border border-border bg-card p-6">
              <span className="flex size-12 items-center justify-center rounded-full bg-primary font-serif text-xl font-bold text-primary-foreground">
                {step.num}
              </span>
              <h3 className="mt-4 font-bold text-card-foreground">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
