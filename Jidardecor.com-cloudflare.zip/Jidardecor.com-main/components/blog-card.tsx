import Image from 'next/image'
import Link from 'next/link'
import { ArrowLeft, Clock3 } from 'lucide-react'
import { formatArabicDate, type BlogPost } from '@/lib/blog'

export function BlogCard({ post }: { post: BlogPost }) {
  return (
    <article className="group overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-shadow hover:shadow-md">
      <Link href={`/blog/${post.slug}`} className="block overflow-hidden">
        <Image
          src={post.image}
          alt={post.imageAlt}
          width={720}
          height={480}
          className="aspect-[3/2] w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
          sizes="(max-width: 768px) 100vw, 33vw"
        />
      </Link>
      <div className="flex flex-col gap-4 p-6">
        <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
          <span className="rounded-full bg-primary/10 px-3 py-1 font-bold text-primary">{post.category}</span>
          <span>{formatArabicDate(post.publishedAt)}</span>
          <span className="inline-flex items-center gap-1"><Clock3 className="size-3.5" />{post.readingMinutes} دقائق</span>
        </div>
        <h2 className="text-balance font-serif text-2xl font-bold leading-snug text-card-foreground">
          <Link href={`/blog/${post.slug}`} className="hover:text-primary">{post.title}</Link>
        </h2>
        <p className="text-pretty text-sm leading-relaxed text-muted-foreground">{post.excerpt}</p>
        <Link href={`/blog/${post.slug}`} className="inline-flex items-center gap-2 text-sm font-bold text-primary">
          اقرأ المقال <ArrowLeft className="size-4" />
        </Link>
      </div>
    </article>
  )
}
