'use client'

import { useState } from 'react'
import { Phone, Loader2, CheckCircle2, AlertCircle } from 'lucide-react'
import { siteConfig, telHref, whatsappHref } from '@/lib/site-config'
import { Button, buttonVariants } from '@/components/ui/button'

type Status = 'idle' | 'loading' | 'success' | 'error'

function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.71.306 1.263.489 1.694.625.712.227 1.36.195 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884" />
    </svg>
  )
}

export function QuoteForm() {
  const [status, setStatus] = useState<Status>('idle')
  const [error, setError] = useState('')

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setStatus('loading')
    setError('')

    const form = e.currentTarget
    const data = Object.fromEntries(new FormData(form).entries())

    try {
      const res = await fetch('/api/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      })
      if (!res.ok) {
        const body = await res.json().catch(() => ({}))
        throw new Error(body.error || 'حدث خطأ ما')
      }
      setStatus('success')
      form.reset()
    } catch (err) {
      setStatus('error')
      setError(err instanceof Error ? err.message : 'تعذّر إرسال الطلب')
    }
  }

  return (
    <section id="quote" className="py-20">
      <div className="mx-auto max-w-6xl px-4">
        <div className="grid items-start gap-10 lg:grid-cols-2">
          <div>
            <h2 className="text-balance text-3xl font-bold text-foreground md:text-4xl">
              اطلب عرض سعر مجاني الآن
            </h2>
            <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
              املأ النموذج وسنتواصل معك في أقرب وقت لتحديد موعد المعاينة داخل
              الرياض. أو تواصل معنا مباشرة عبر الاتصال أو الواتساب.
            </p>

            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <a
                href={telHref}
                className={buttonVariants({ variant: 'outline', size: 'lg', className: 'h-11 px-5' })}
              >
                <Phone className="size-5" />
                {siteConfig.phoneDisplay}
              </a>
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className={buttonVariants({
                  size: 'lg',
                  className: 'h-11 bg-[#25D366] px-5 text-white hover:bg-[#1eb959]',
                })}
              >
                <WhatsAppIcon className="size-5" />
                واتساب
              </a>
            </div>

            <dl className="mt-8 space-y-2 text-sm text-muted-foreground">
              <div className="flex gap-2">
                <dt className="font-semibold text-foreground">ساعات العمل:</dt>
                <dd>{siteConfig.hours}</dd>
              </div>
              <div className="flex gap-2">
                <dt className="font-semibold text-foreground">منطقة الخدمة:</dt>
                <dd>جميع أحياء {siteConfig.city}</dd>
              </div>
            </dl>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
            {status === 'success' ? (
              <div className="flex flex-col items-center py-10 text-center">
                <CheckCircle2 className="size-14 text-primary" />
                <h3 className="mt-4 text-xl font-bold text-card-foreground">
                  تم استلام طلبك بنجاح
                </h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  سنتواصل معك في أقرب وقت ممكن. شكرًا لثقتك بنا.
                </p>
                <Button className="mt-6" onClick={() => setStatus('idle')}>
                  إرسال طلب آخر
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="grid gap-4">
                <Field label="الاسم" name="name" placeholder="أدخل اسمك" required />
                <Field
                  label="رقم الجوال"
                  name="phone"
                  type="tel"
                  placeholder="05xxxxxxxx"
                  required
                  inputMode="tel"
                />
                <div className="grid gap-2">
                  <label htmlFor="service" className="text-sm font-medium text-foreground">
                    نوع الخدمة
                  </label>
                  <select
                    id="service"
                    name="service"
                    className="h-11 rounded-lg border border-input bg-background px-3 text-sm text-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-ring/40"
                    defaultValue=""
                  >
                    <option value="" disabled>
                      اختر نوع الخدمة
                    </option>
                    <option>تركيب ورق جدران ثلاثي الأبعاد</option>
                    <option>ورق جدران لغرف المنزل</option>
                    <option>ورق جدران للمجالس</option>
                    <option>ورق جدران للمكاتب والمحلات</option>
                    <option>ورق جدران لغرف الأطفال</option>
                    <option>أخرى</option>
                  </select>
                </div>
                <Field
                  label="الحي / الموقع"
                  name="area"
                  placeholder="مثال: حي النرجس"
                />
                <div className="grid gap-2">
                  <label htmlFor="message" className="text-sm font-medium text-foreground">
                    تفاصيل إضافية (اختياري)
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows={3}
                    placeholder="أخبرنا عن المساحة التقريبية أو أي تفاصيل أخرى"
                    className="rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-ring/40"
                  />
                </div>

                {status === 'error' && (
                  <p className="flex items-center gap-2 text-sm text-destructive">
                    <AlertCircle className="size-4" />
                    {error}
                  </p>
                )}

                <Button type="submit" size="lg" disabled={status === 'loading'}>
                  {status === 'loading' ? (
                    <>
                      <Loader2 className="size-4 animate-spin" />
                      جارٍ الإرسال...
                    </>
                  ) : (
                    'إرسال الطلب'
                  )}
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

function Field({
  label,
  name,
  type = 'text',
  placeholder,
  required,
  inputMode,
}: {
  label: string
  name: string
  type?: string
  placeholder?: string
  required?: boolean
  inputMode?: 'tel' | 'text'
}) {
  return (
    <div className="grid gap-2">
      <label htmlFor={name} className="text-sm font-medium text-foreground">
        {label} {required && <span className="text-destructive">*</span>}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        inputMode={inputMode}
        placeholder={placeholder}
        required={required}
        className="h-11 rounded-lg border border-input bg-background px-3 text-sm text-foreground focus:border-primary focus:outline-none focus:ring-2 focus:ring-ring/40"
      />
    </div>
  )
}
