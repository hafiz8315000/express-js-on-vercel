'use client'

import { Copy, MessageCircle } from 'lucide-react'
import { useState } from 'react'

export function ArticleShare({ title }: { title: string }) {
  const [copied, setCopied] = useState(false)

  const copyLink = async () => {
    await navigator.clipboard.writeText(window.location.href)
    setCopied(true)
    window.setTimeout(() => setCopied(false), 1800)
  }

  return (
    <div className="flex flex-wrap items-center gap-3" aria-label="مشاركة المقال">
      <span className="text-sm font-bold text-foreground">شارك المقال:</span>
      <a
        href={`https://wa.me/?text=${encodeURIComponent(title)}`}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-2 rounded-lg bg-[#25D366] px-4 py-2 text-sm font-bold text-white hover:bg-[#1eb959]"
      >
        <MessageCircle className="size-4" /> واتساب
      </a>
      <button type="button" onClick={copyLink} className="inline-flex items-center gap-2 rounded-lg border border-border bg-background px-4 py-2 text-sm font-bold text-foreground hover:bg-secondary">
        <Copy className="size-4" /> {copied ? 'تم النسخ' : 'نسخ الرابط'}
      </button>
    </div>
  )
}
