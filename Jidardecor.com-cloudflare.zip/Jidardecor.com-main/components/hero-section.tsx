import Image from 'next/image'
import { Phone, CheckCircle2 } from 'lucide-react'
import { siteConfig, telHref } from '@/lib/site-config'
import { buttonVariants } from '@/components/ui/button'

const highlights = [
  'فني تركيب محترف',
  'ضمان على التركيب',
  'أسعار منافسة',
  'خدمة داخل الرياض',
]

export function HeroSection() {
  return (
    <section id="home" className="relative overflow-hidden">
      <div className="absolute inset-0">
        <Image
          src="/hero.webp"
          alt="تركيب ورق جدران فاخر في مجلس بالرياض"
          fill
          priority
          fetchPriority="high"
          className="object-cover"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-foreground/85 via-foreground/60 to-foreground/30" />
      </div>

      <div className="relative mx-auto max-w-6xl px-4 py-24 md:py-32">
        <div className="max-w-2xl">
          <p className="mb-4 inline-block rounded-full bg-primary/90 px-4 py-1.5 text-sm font-semibold text-primary-foreground">
            معلم تركيب ورق جدران في {siteConfig.city}
          </p>
          <h1 className="text-balance text-4xl font-bold leading-tight text-background md:text-5xl lg:text-6xl">
            توريد وتركيب ورق الجدران الفاخر بالرياض
          </h1>
          <p className="mt-5 text-pretty text-lg leading-relaxed text-background/90">
            نحوّل جدرانك إلى تحفة فنية. تركيب احترافي لورق الحائط ثلاثي الأبعاد
            والفينيل والديكورات الحديثة للمنازل والمكاتب والمجالس في جميع أحياء
            الرياض، مع ضمان الجودة وأفضل الأسعار.
          </p>

          <ul className="mt-6 grid grid-cols-2 gap-3">
            {highlights.map((item) => (
              <li key={item} className="flex items-center gap-2 text-background">
                <CheckCircle2 className="size-5 shrink-0 text-primary" />
                <span className="text-sm font-medium">{item}</span>
              </li>
            ))}
          </ul>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a href="#quote" className={buttonVariants({ size: 'lg', className: 'h-12 px-6 text-base' })}>
              احصل على عرض سعر مجاني
            </a>
            <a
              href={telHref}
              className={buttonVariants({
                variant: 'secondary',
                size: 'lg',
                className: 'h-12 px-6 text-base',
              })}
            >
              <Phone className="size-5" />
              {siteConfig.phoneDisplay}
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
